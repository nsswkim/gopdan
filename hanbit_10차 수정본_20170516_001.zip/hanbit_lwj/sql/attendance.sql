drop table attendance;
create table attendance(
	userID varchar(20),
	lecNum int,
	lecDate date,
	inTime datetime,
	outTime datetime,
	attendanceState int
);

select * from attendance;
commit;