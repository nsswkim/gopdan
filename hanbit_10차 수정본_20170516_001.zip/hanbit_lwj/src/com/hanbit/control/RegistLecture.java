package com.hanbit.control;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanbit.key.KeyClass;
import com.hanbit.key.UserKey;

@SuppressWarnings("serial")
@WebServlet(
		urlPatterns = { "/registLecture" }, 
		initParams = { 
				@WebInitParam(name = "url", value = "jdbc:mysql://localhost:3306/testdb"), 
				@WebInitParam(name = "id", value = "scott"), 
				@WebInitParam(name = "pw", value = "tiger")
		})
public class RegistLecture extends HttpServlet {
	protected void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding ("UTF-8");
		
		boolean isExist = false;
		boolean result = false;
		String profId = ((UserKey) request.getSession().getAttribute("userkey")).getId ();
		String lec_name = request.getParameter ("lecName");
		Date lec_DateStart = Date.valueOf (request.getParameter ("lecDateStart"));
		Date lec_DateClose = Date.valueOf (request.getParameter ("lecDateClose"));
		int lec_TimeStart = Integer.parseInt (request.getParameter ("lecTimeStart"));
		int lec_TimeClose = Integer.parseInt (request.getParameter ("lecTimeClose"));
		String lec_TimeDesc = request.getParameter ("lecTimeDesc");
		String lec_info = request.getParameter ("lecInfo");
		String lec_desc = request.getParameter ("lecDesc");
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		Calendar cal = Calendar.getInstance ();
		Date date = Date.valueOf (cal.get (Calendar.YEAR) + "-" + (cal.get (Calendar.MONTH) + 1) + "-" + cal.get (Calendar.DATE));
		System.out.println (date);
		System.out.println (profId);
		System.out.println (lec_name);
		System.out.println (lec_DateStart);
		System.out.println (lec_DateClose);
		System.out.println (lec_TimeStart);
		System.out.println (lec_TimeClose);
		System.out.println (lec_TimeDesc);
		System.out.println (lec_info);
		System.out.println (lec_desc);
		
		try {
			conn = KeyClass.getConnection (getInitParameter ("url"), getInitParameter ("id"), getInitParameter ("pw"));
			
			try {
				pstmt = conn.prepareStatement ("select * from lecture where profId = ? and lecState >= 0");
				pstmt.setString (1, profId);
				rset = pstmt.executeQuery ();
				
				if (rset.next ()) {
					if (date.after (rset.getDate ("lecDateStart")) && date.before (rset.getDate ("lecDateClose"))) isExist = true;
					else isExist = false;
				} else isExist = false;
			} catch (Exception e) {
			} finally {
				try {
					if (rset != null) rset.close ();
					if (pstmt != null) pstmt.close ();
				} catch (Exception e) {}
			}
			
			try {
				if (isExist) {
					pstmt = conn.prepareStatement ("update lecture set lecName=?, lecState=?, lecTimeStart=?, lecTimeClose=?, lecTimeDesc=?, "
							+ "lecInfo=?, lecDesc=? where profId=?");
					pstmt.setString (1, lec_name);
					pstmt.setInt (2, 0);
					pstmt.setInt (3, lec_TimeStart);
					pstmt.setInt (4, lec_TimeClose);
					pstmt.setString (5, lec_TimeDesc);
					pstmt.setString (6, lec_info);
					pstmt.setString (7, lec_desc);
					pstmt.setString (8, profId);
				} else {
					pstmt = conn.prepareStatement ("insert into lecture values (?, lecNum, ?, 0, ?, ?, ?, ?, ?, ?, ?, 0)");
					pstmt.setString (1, profId);
					pstmt.setString (2, lec_name);
					pstmt.setDate (3, lec_DateStart);
					pstmt.setDate (4, lec_DateClose);
					pstmt.setInt (5, lec_TimeStart);
					pstmt.setInt (6, lec_TimeClose);
					pstmt.setString (7, lec_TimeDesc);
					pstmt.setString (8, lec_info);
					pstmt.setString (9, lec_desc);
				}	
				result = pstmt.executeUpdate () != 0? true : false;
			} catch (Exception e) {
			} finally {
				try { if (pstmt != null) pstmt.close (); }
				catch (Exception e) {}
			}
		} catch (Exception e) { e.printStackTrace ();
		} finally {
			try { if (conn != null) conn.close (); }
			catch (Exception e) {}
		}
		
		if (result) {
			response.sendRedirect ("management.jsp");
		} else {
			response.sendRedirect ("management.jsp?err=1");
		}
	}
}