package com.hanbit.control;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanbit.key.KeyClass;

@SuppressWarnings ("serial")
@WebServlet(
		urlPatterns = { "/requestoffer" }, 
		initParams = { 
				@WebInitParam(name = "url", value = "jdbc:mysql://localhost:3306/testdb"), 
				@WebInitParam(name = "id", value = "scott"), 
				@WebInitParam(name = "pw", value = "tiger")
		})
public class RequestOfferProc extends HttpServlet {
	protected void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding ("UTF-8");
		
		int errCode = 0;
		
		String coname = request.getParameter ("coname").trim ();
		String coregnum = request.getParameter ("coregnum").trim ();
		String name = request.getParameter ("name").trim ();
		String contact = request.getParameter ("contact").trim ();
		String phone = request.getParameter ("phone").trim ();
		String email = request.getParameter ("email").trim ();
		String recruitarea = request.getParameter ("recruitarea").trim ();
		String mainbusiness = request.getParameter ("mainbusiness").trim ();
		String workplace = request.getParameter ("workplace").trim ();
		String salary = request.getParameter ("salary").trim ();
		String skill = request.getParameter ("skill").trim ();
		String education = request.getParameter ("education").trim ();
		String gender = request.getParameter ("gender").trim ();
		
		if (coname.isEmpty () || "".equals (coname)) errCode = 2;
		else if (coname.length () > 20) errCode = 3;
		
		else if (coregnum.isEmpty () || "".equals (coregnum)) errCode = 4;
		else if (coregnum.length () > 40) errCode = 5;
		
		else if (name.isEmpty () || "".equals (name)) errCode = 6;
		else if (name.length () > 20) errCode = 7;
		
		else if (contact.isEmpty () || "".equals (contact)) errCode = 8;
		else if (contact.length () > 13) errCode = 9;
		
		else if (phone.isEmpty () || "".equals (phone)) errCode = 10;
		else if (phone.length () > 13) errCode = 11;
		
		else if (email.isEmpty () || "".equals (email)) errCode = 12;
		else if (email.length () > 40) errCode = 13;
		else {
			Connection conn = null;
			PreparedStatement pstmt = null;
			
			try {
				conn = KeyClass.getConnection (getInitParameter ("url"), getInitParameter ("id"), getInitParameter ("pw"));
				pstmt = conn.prepareStatement ("insert into offerrequest values (num, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
				pstmt.setString ( 1, coname);
				pstmt.setString ( 2, coregnum);
				pstmt.setString ( 3, name);
				pstmt.setString ( 4, contact);
				pstmt.setString ( 5, phone);
				pstmt.setString ( 6, email);
				pstmt.setString ( 7, recruitarea);
				pstmt.setString ( 8, mainbusiness);
				pstmt.setString ( 9, workplace);
				pstmt.setString (10, salary);
				pstmt.setString (11, skill);
				pstmt.setString (12, education);
				pstmt.setString (13, gender);
				errCode = pstmt.executeUpdate ();
			} catch (Exception e) { errCode = -1;
			} finally {
				try {
					if (pstmt != null) pstmt.close ();
					if (conn != null) conn.close ();
				} catch (Exception e) {}
			}
		}
		
		if (errCode == 1) response.sendRedirect ("reqofferreceived.jsp");
		else response.sendRedirect ("community.jsp?pg=3&err="+errCode);
	}
}