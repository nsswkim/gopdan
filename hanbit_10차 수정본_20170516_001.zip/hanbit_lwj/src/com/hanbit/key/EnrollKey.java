package com.hanbit.key;

public class EnrollKey {
	int lecNum = 0;
	String lecLocation = "";
	int lecCapacity = 0;
	String lecPicture = "";
	int enrollState = 0;
	
	public EnrollKey () {}
	public EnrollKey (int lecNum, String lecLocation, int lecCapacity, String lecPicture, int enrollState) {
		this.lecNum = lecNum;
		this.lecLocation = lecLocation;
		this.lecCapacity = lecCapacity;
		this.lecPicture = lecPicture;
		this.enrollState = enrollState;
	}
	
	public int getLecNum () { return lecNum; }
	public String getLecLocation () { return lecLocation; }
	public int getLecCapacity () { return lecCapacity; }
	public String getLecPicture () { return lecPicture; }
	public int enrollState () { return enrollState; }
	
	public void setLecNum (int lecNum) { this.lecNum = lecNum; }
	public void setLecLocation (String lecLocation) { this.lecLocation = lecLocation; }
	public void setLecCapacity (int lecCapacity) { this.lecCapacity = lecCapacity; }
	public void setLecPicture (String lecPicture) { this.lecPicture = lecPicture; }
	public void setEnrollState (int enrollState) { this.enrollState = enrollState; }
}