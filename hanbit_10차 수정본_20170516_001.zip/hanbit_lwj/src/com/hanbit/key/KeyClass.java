package com.hanbit.key;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class KeyClass {
	private static Connection conn = null;
	private static String driver = "com.mysql.jdbc.Driver";
	
	private KeyClass () {}
	
	public static Connection getConnection (String url, String id, String pw) throws SQLException, ClassNotFoundException {
		if (conn == null || conn.isClosed ()) {
			Class.forName (driver);
			conn = DriverManager.getConnection (url, id, pw);
		}
		
		return conn;
	}
}