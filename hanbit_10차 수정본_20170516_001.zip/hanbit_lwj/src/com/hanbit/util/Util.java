package com.hanbit.util;

public class Util {
	public String pageNaming (int count) {
		String stringNum = Integer.toString (count);
		if (stringNum.length() < 2) stringNum = "0" + stringNum;
		
		return stringNum;
	}
	
	public static int min (int a, int b) { return a<b? a : b; }
}