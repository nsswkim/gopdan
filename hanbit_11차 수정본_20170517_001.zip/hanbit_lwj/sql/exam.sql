drop table exam;
create table exam (
	lecNum int not null,
	examNum int auto_increment primary key,
	examTitle varchar(40) not null,
	examInfo varchar(40),
	examDate DATE not null,
	examTimeStart int not null,
	examTimeClose int not null
);
select * from exam;
commit;