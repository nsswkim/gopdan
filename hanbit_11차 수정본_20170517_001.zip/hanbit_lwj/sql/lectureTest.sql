drop table lectureTest;
create table lectureTest (
	num int primary key auto_increment,
	lecNum int not null,
	notice varchar(1024) not null
);

select * from lectureTest;
commit;