drop table resourceBoard;
create table resourceBoard (
	num int primary key auto_increment,
	lecNum int not null,
	state int default 0,
	authRead int default 0,
	authWrite int default 0
);
select * from resourceBoard;
commit;