drop table testDetail;
create table testDetail(
   lecNum int not null,
   testNum int auto_increment primary key,
   testDate DATE not null,
   testDetail varchar(128),
   testCutLine int
);
select * from testDetail;
commit;