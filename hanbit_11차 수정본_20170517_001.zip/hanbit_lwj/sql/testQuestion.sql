drop table testQuestion;
create table testQuestion(
   lecNum int not null,
   testNum int not null,
   questNum int auto_increment primary key,
   questText varchar(128) not null,
   questScore int not null,
   crt varchar(128) not null,
   incrt1 varchar(128),
   incrt2 varchar(128),
   incrt3 varchar(128),
   incrt4 varchar(128)
);
select * from testQuestion;
commit;