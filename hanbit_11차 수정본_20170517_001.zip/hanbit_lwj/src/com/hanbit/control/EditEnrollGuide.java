package com.hanbit.control;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanbit.key.KeyClass;
import com.hanbit.util.Util;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.FileRenamePolicy;

@SuppressWarnings("serial")
@WebServlet(
		urlPatterns = { "/editEnrollGuideline" }, 
		initParams = { 
				@WebInitParam(name = "url", value = "jdbc:mysql://localhost:3306/testdb"), 
				@WebInitParam(name = "id", value = "scott"), 
				@WebInitParam(name = "pw", value = "tiger")
		})
public class EditEnrollGuide extends HttpServlet {
	protected void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding ("UTF-8");
		
		int lecNum = 0;
		String lecLocation = null;
		int lecCapacity = 0;
		String picture = "";
		
		request.setCharacterEncoding ("UTF-8");
	    int maxSize = 1024 * 1024 * 10;
	    String savePath = "C:\\www\\hanbit_lwj\\WebContent\\lecPicture";
	    System.out.println (new File (savePath).isDirectory ());
	    String uploadFile = "";
	    File file = null;
	    CustomFileRenamePolicy cfrp = new CustomFileRenamePolicy ();
	    
	    try {
	    	MultipartRequest multi = new MultipartRequest (request, savePath, maxSize, "UTF-8", cfrp);
	    	
	    	lecNum = Integer.parseInt (multi.getParameter ("lecNum"));
			lecLocation = multi.getParameter ("lecLocation");
			lecCapacity = Integer.parseInt (multi.getParameter ("lecCapacity"));
			try { picture = multi.getParameter ("lecPicture"); }
			catch (Exception e) { picture = ""; }
	    	uploadFile = "/" + multi.getFilesystemName ("lecPicture");
	    	file = new File (savePath + uploadFile);
	    } catch (Exception e) {
	    	e.printStackTrace ();
	    }
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		try {
			conn = KeyClass.getConnection (getInitParameter ("url"), getInitParameter ("id"), getInitParameter ("pw"));
			
			try {
				pstmt = conn.prepareStatement ("insert into enrolment values (?, ?, ?, ?, ?)");
				System.out.println (lecNum);
				System.out.println (lecLocation);
				System.out.println (lecCapacity);
				System.out.println (cfrp.recentName);
				pstmt.setInt (1, lecNum);
				pstmt.setString (2, lecLocation);
				pstmt.setInt (3, lecCapacity);
				pstmt.setString (4, cfrp.getRecentName ());
				pstmt.setInt (5, 1);
				pstmt.executeUpdate ();
			} catch (Exception e) { e.printStackTrace ();
			} finally {
				try {
					if (rset != null) rset.close ();
					if (pstmt != null) pstmt.close ();
				} catch (Exception e) {}
			}
			
			try {
				pstmt = conn.prepareStatement ("update lecture set lecState = ? where lecNum = ?");
				pstmt.setInt (1, 3);
				pstmt.setInt (2, lecNum);
				pstmt.executeUpdate ();
			} catch (Exception e) { e.printStackTrace ();
			} finally {
				try {
					if (rset != null) rset.close ();
					if (pstmt != null) pstmt.close ();
				} catch (Exception e) {}
			}
		} catch (Exception e) {
		} finally {
			try {
				if (conn != null) conn.close ();
			} catch (Exception e) {}
		}
		
		response.sendRedirect ("management.jsp");
	}
}

class CustomFileRenamePolicy implements FileRenamePolicy {
	Util util = new Util ();
	String recentName = "";
	
	@Override public File rename (File f) {
		if (createNewFile (f)) { return f; }
		String name = f.getName ();
		String body = null;
		String ext = null;
		 
		int dot = name.lastIndexOf (".");
		if (dot != -1) {
			body = name.substring (0, dot);
			ext = name.substring (dot);
		} else {
			body = name;
			ext = "";
		}
		
		int count = 0;
		while (!createNewFile(f) && count < 9999) {
			count++;
			String newName = body + "_" + util.pageNaming (count) + ext;
			recentName = newName;
			f = new File(f.getParent(), newName);
		}

		return f;
	}
		 
	private boolean createNewFile(File f) {
		try {
			return f.createNewFile();
		} catch (IOException ignored) {
			return false;
		}
	}
	
	public String getRecentName () { return this.recentName; }
}