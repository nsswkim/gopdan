package com.hanbit.key;

import java.sql.Date;

public class ExamKey {
	private int lecNum;
	private int examNum;
	private String examTitle;
	private String examInfo;
	private Date examDate;
	private int examTimeStart;
	private int examTimeClose;
	
	public ExamKey () {}
	
	public int getLecNum () { return lecNum; }
	public int getExamNum () { return examNum; }
	public String getExamTitle () { return examTitle; }
	public String getExamInfo () { return examInfo; }
	public Date getExamDate () { return examDate; }
	public int getExamTimeStart () { return examTimeStart; }
	public int getExamTimeClose () { return examTimeClose; }
	
	public void setLecNum (int lecNum) { this.lecNum = lecNum; }
	public void setExamNum (int examNum) { this.examNum = examNum; }
	public void setExamTitle (String examTitle) { this.examTitle = examTitle; }
	public void setExamInfo (String examInfo) { this.examInfo = examInfo; }
	public void setExamDate (Date examDate) { this.examDate = examDate; }
	public void setExamTimeStart (int examTimeStart) { this.examTimeStart = examTimeStart; }
	public void setExamTimeClose (int examTimeClose) { this.examTimeClose = examTimeClose; };
}