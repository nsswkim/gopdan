package com.hanbit.key;

import java.sql.Date;

public class UserKey {
	private int num;
	private String name;
	private String id;
	private String pw;
	private String email;
	private Date date;
	private String phone;
	private int job;
	private int classNum;
	
	public UserKey () {}
	public UserKey (int num, String name, String id, String pw,
			String email, Date date, String phone, int job, int classNum) {
		this.num = num;
		this.name = name;
		this.id = id;
		this.pw = pw;
		this.email = email;
		this.date = date;
		this.phone = phone;
		this.job = job;
		this.classNum = classNum;
	}
	
	public int getNum () { return num; }
	public String getName () { return name; }
	public String getId () { return id; }
	public String getPw () { return pw; }
	public String getEmail () { return email; }
	public String getPhone () { return phone; }
	public Date getDate () { return date; }
	public int getJob () { return job; }
	public int getClassNum () { return classNum; }

	public void setNum (int num) { this.num = num; }
	public void setName (String name) { this.name = name; }
	public void setId (String id) { this.id = id; }
	public void setPw (String pw) { this.pw = pw; }
	public void setEmail (String email) { this.email = email; }
	public void setDate (Date date) { this.date = date; }
	public void setPhone (String phone) { this.phone = phone; }
	public void setJob (int job) { this.job = job; }
	public void setClassNum (int lecNum) { this.classNum = lecNum; }
}