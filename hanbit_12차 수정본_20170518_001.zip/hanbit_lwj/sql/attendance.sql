drop table attendance;
create table attendance(
	userID varchar(20) not null,
	lecNum int not null,
	lecDate date,
	inTime datetime,
	outTime datetime,
	attendanceState int
);

insert into attendance values ('student01', 1001, '2017-05-01', '2017-05-01 09:00:00', '2017-05-01 18:00:00', 8);
insert into attendance values ('student01', 1001, '2017-05-02', '2017-05-02 09:00:00', '2017-05-02 18:00:00', 8);
insert into attendance values ('student01', 1001, '2017-05-03', '2017-05-03 09:00:00', '2017-05-03 18:00:00', 8);
insert into attendance values ('student01', 1001, '2017-05-04', '2017-05-04 09:00:00', '2017-05-04 18:00:00', 8);
insert into attendance values ('student01', 1001, '2017-05-05', '2017-05-05 09:00:00', '2017-05-05 18:00:00', 8);
insert into attendance values ('student01', 1001, '2017-05-08', '2017-05-08 09:00:00', '2017-05-08 18:00:00', 8);
insert into attendance values ('student01', 1001, '2017-05-09', '2017-05-09 09:00:00', '2017-05-09 18:00:00', 8);
insert into attendance values ('student01', 1001, '2017-05-10', '2017-05-10 09:00:00', '2017-05-10 18:00:00', 8);
insert into attendance values ('student01', 1001, '2017-05-11', '2017-05-11 09:00:00', '2017-05-11 18:00:00', 8);
insert into attendance values ('student01', 1001, '2017-05-12', '2017-05-12 09:00:00', '2017-05-12 18:00:00', 8);
insert into attendance values ('student01', 1001, '2017-05-15', '2017-05-15 09:00:00', '2017-05-15 18:00:00', 8);
insert into attendance values ('student01', 1001, '2017-05-16', '2017-05-16 09:00:00', '2017-05-16 18:00:00', 8);
insert into attendance values ('student01', 1001, '2017-05-17', '2017-05-17 09:00:00', null, 3);

select * from attendance;
commit;