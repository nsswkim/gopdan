package com.hanbit.control;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanbit.key.KeyClass;
import com.hanbit.key.UserKey;

@SuppressWarnings("serial")
@WebServlet(
		urlPatterns = { "/AddExam" }, 
		initParams = { 
				@WebInitParam(name = "url", value = "jdbc:mysql://localhost:3306/testdb"), 
				@WebInitParam(name = "id", value = "scott"), 
				@WebInitParam(name = "pw", value = "tiger")
		})
public class AddExam extends HttpServlet {
	protected void doGet (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding ("UTF-8");
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		UserKey uk = (UserKey) request.getSession().getAttribute ("userkey");
		
		try {
			conn = KeyClass.getConnection (getInitParameter ("url"), getInitParameter ("id"), getInitParameter ("pw"));
			pstmt = conn.prepareStatement ("insert into exam (lecNum, examTitle) values (?, ?)");
			pstmt.setInt (1, uk.getClassNum ());
			pstmt.setString (2, "������ ����");
			pstmt.executeUpdate ();
		} catch (Exception e) { e.printStackTrace ();
		} finally {
			try {
				if (rset != null) rset.close ();
				if (pstmt != null) pstmt.close ();
				if (conn != null) conn.close ();
			} catch (Exception e) {}
		}
		
		response.sendRedirect ("management.jsp");
	}
}