package com.hanbit.control;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanbit.key.KeyClass;
import com.hanbit.key.UserKey;

@SuppressWarnings("serial")
@WebServlet(
		urlPatterns = { "/AddQNA" }, 
		initParams = { 
				@WebInitParam(name = "url", value = "jdbc:mysql://localhost:3306/testdb"), 
				@WebInitParam(name = "id", value = "scott"), 
				@WebInitParam(name = "pw", value = "tiger")
		})
public class AddQNA extends HttpServlet {
	protected void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding ("UTF-8");
		
		String wid = request.getParameter ("wid");
		String sub =request.getParameter ("sub");
		String content = request.getParameter ("content");
		UserKey uk = (UserKey) request.getSession().getAttribute("userkey");
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = KeyClass.getConnection (getInitParameter ("url"), getInitParameter ("id"), getInitParameter ("pw"));
			pstmt = conn.prepareStatement ("insert into question (wid, sub, content, nalja, email) values (?, ?, ?, sysdate(), ?)");
			pstmt.setString (1, wid);
			pstmt.setString (2, sub);
			pstmt.setString (3, content);
			if (uk != null) pstmt.setString (4, uk.getEmail ());
			else pstmt.setString (4, null);
			pstmt.executeUpdate ();
		} catch (Exception e) { e.printStackTrace ();
		} finally {
			try {
				if (pstmt != null) pstmt.close ();
				if (conn != null) conn.close ();
			} catch (Exception e) {}
		}
		
		response.sendRedirect ("qna.jsp");
	}
}