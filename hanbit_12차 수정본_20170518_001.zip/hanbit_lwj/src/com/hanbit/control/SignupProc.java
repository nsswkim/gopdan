package com.hanbit.control;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanbit.key.KeyClass;

@WebServlet(
		urlPatterns = { "/signupquery" }, 
		initParams = { 
				@WebInitParam(name = "url", value = "jdbc:mysql://localhost:3306/testdb"), 
				@WebInitParam(name = "id", value = "scott"), 
				@WebInitParam(name = "pw", value = "tiger")
		})
public class SignupProc extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding ("UTF-8");
		boolean result = false;
		int errCode = 0;
		
		String sign_id = request.getParameter ("id").trim ();
		String sign_pw = request.getParameter ("pw").trim ();
		String sign_rpw = request.getParameter ("rpw").trim ();
		String sign_name = request.getParameter ("name").trim ();
		String sign_callnum = request.getParameter ("callnum").trim ();
		String sign_mailaddr = request.getParameter ("mailaddr").trim ();
		
		if (sign_id.isEmpty () || sign_id.length () < 4) { errCode = 11; System.out.println (errCode); }
		else if (sign_id.length () > 10) { errCode = 12; System.out.println (errCode); }
		else if (chkString (sign_id) == false) { errCode = 13; System.out.println (errCode); }
		else if (sign_id.equals ("admin")) { errCode = 19; System.out.println (errCode); }
		
		else if (sign_pw.isEmpty () || sign_rpw.isEmpty ()) { errCode = 21; System.out.println (errCode); }
		else if (sign_pw.length () < 4 || sign_rpw.length() < 4) { errCode = 22; System.out.println (errCode); }
		else if (sign_pw.length () > 10 || sign_rpw.length() > 10) { errCode = 23; System.out.println (errCode); }
		else if (chkString (sign_pw) == false || chkString (sign_rpw) == false) { errCode = 24; System.out.println (errCode); }
		else if (!sign_pw.equals (sign_rpw)) { errCode = 25; System.out.println (errCode); }
		
		else if (sign_name.isEmpty ()) { errCode = 31; System.out.println (errCode); }
		else if (sign_name.length () > 10) { errCode = 32; System.out.println (errCode); }
		else if (chkString (sign_name) == null) { errCode = 33; System.out.println (errCode); }
		
		else if (sign_callnum.isEmpty ()) { errCode = 41; System.out.println (errCode); }
		else if (sign_callnum.length () > 11) { errCode = 42; System.out.println (errCode); }
		else if (sign_callnum.contains ("-")) { errCode = 43; System.out.println (errCode); }
		
		else if (sign_mailaddr.isEmpty ()) { errCode = 51; System.out.println (errCode); }
		else if (!sign_mailaddr.contains ("@")) { errCode = 52; System.out.println (errCode); }
		else if (!sign_mailaddr.contains (".")) { errCode = 53; System.out.println (errCode); }
		else errCode = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		try {
			conn = KeyClass.getConnection (getInitParameter ("url"), getInitParameter ("id"), getInitParameter ("pw"));
			pstmt = conn.prepareStatement ("select * from member where id = ? or phone = ? or email = ?");
			pstmt.setString (1, sign_id);
			pstmt.setString (2, sign_callnum);
			pstmt.setString (3, sign_mailaddr);
			rset = pstmt.executeQuery ();
			
			if (rset.next ()) {
				result = false;
				
				if (rset.getString ("id").equals (sign_id)) { errCode = 61; System.out.println (errCode); }
				else if (rset.getString ("phone").equals (sign_callnum) || rset.getString ("email").equals (sign_mailaddr))
					{ errCode = 62; System.out.println (errCode); }
			} else result = true;
		} catch (SQLException e) { e.printStackTrace ();
		} catch (ClassNotFoundException e) { e.printStackTrace ();
		} finally {
			try {
				if (rset != null) rset.close ();
				if (pstmt != null) pstmt.close ();
				if (conn != null) conn.close ();
			} catch (Exception e) {}
		}
		
		System.out.println ("Check Point " + errCode);
		
		if (errCode == 0 && result) {
			try {
				conn = KeyClass.getConnection (getInitParameter ("url"), getInitParameter ("id"), getInitParameter ("pw"));
				pstmt = conn.prepareStatement ("insert into member values (num, ?, ?, ?, ?, sysdate(), ?, 0, 0)");
				pstmt.setString (1, sign_name);
				pstmt.setString (2, sign_id);
				pstmt.setString (3, sign_pw);
				pstmt.setString (4, sign_mailaddr);
				pstmt.setString (5, sign_callnum);
				pstmt.executeUpdate ();
				
				response.sendRedirect ("welcome.jsp");
			} catch (Exception e) {
			} finally {
				try {
					if (pstmt != null) pstmt.close ();
					if (conn != null) conn.close ();
				} catch (Exception e) {}
			}
		} else response.sendRedirect ("signup.jsp?err=" + errCode);
	}

	private Boolean chkString (String chkText) {
		Boolean chkflag = true;
		char[] charArray = chkText.toCharArray ();
		
		for (int count = 0 ; count<chkText.length() ; count++) {
			if (!Character.isAlphabetic (charArray[count]) && !Character.isDigit (charArray[count])) chkflag = false;
		}
		
		return chkflag;
	}
}