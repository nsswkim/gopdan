package com.hanbit.key;

import java.sql.Date;

public class QnaKey {
	private int idx;
	private String wid;
	private String sub;
	private String content;
	private Date nalja;
	private String email;

	public QnaKey () {}

	public int getIdx () { return idx; }
	public String getWid () { return wid; }
	public String getSub () { return sub; }
	public String getContent () { return content; }
	public Date getNalja () { return nalja; }
	public String getEmail () { return email; }

	public void setIdx (int idx) { this.idx = idx; }
	public void setWid (String wid) { this.wid = wid; }
	public void setSub (String sub) { this.sub = sub; }
	public void setContent (String content) { this.content = content; }
	public void setNalja (Date nalja) { this.nalja = nalja; }
	public void setEmail (String email) { this.email = email; }
}