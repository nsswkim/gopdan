$(document).ready (function () {
	$('.modal').hide ();
    $('.login').click (function () {
    	$('.modal').fadeToggle ("fase");
        return false;
    });
    $('.logout').click (function () {
    	location.href = "logout.jsp";
    	return false;
    });
    $('.close').click (function () {
        $('.modal').fadeToggle ("fase");
        return false;
    })
});