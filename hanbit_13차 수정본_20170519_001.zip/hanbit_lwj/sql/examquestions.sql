drop table examquestions;
create table examquestions (
	idx int primary key auto_increment,
	examNum int not null,
	exqPoint int default 0,
	exqText varchar(1024) not null,
	selectO varchar(1024) not null,
	selectX1 varchar(1024) not null,
	selectX2 varchar(1024) not null,
	selectX3 varchar(1024) not null,
	selectX4 varchar(1024) not null
);
select * from examquestions;
commit;