drop table offerrequest;
create table offerrequest(
   requestnumber int auto_increment primary key,
   coname varchar(20) not null,
   coregnum varchar(40) not null,
   name varchar(20) not null,
   contact varchar(13) not null,
   phone varchar(13) not null,
   email varchar(40) not null,
   recruitarea varchar(20),
   mainbusiness varchar(20),
   workplace varchar(20),
   salary varchar(20),
   skill varchar(20),
   education varchar(20),
   gender varchar(20)
);
select * from offerrequest;