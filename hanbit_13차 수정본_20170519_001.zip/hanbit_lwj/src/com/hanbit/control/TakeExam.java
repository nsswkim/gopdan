package com.hanbit.control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanbit.key.KeyClass;

@SuppressWarnings("serial")
@WebServlet(
		urlPatterns = { "/takeExam" }, 
		initParams = { 
				@WebInitParam(name = "url", value = "jdbc:mysql://localhost:3306/testdb"), 
				@WebInitParam(name = "id", value = "scott"), 
				@WebInitParam(name = "pw", value = "tiger")
		})
public class TakeExam extends HttpServlet {
	protected void doGet (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding ("UTF-8");
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		Date toDay = new java.sql.Date (Calendar.getInstance().getTime().getTime());
		Calendar cal = Calendar.getInstance ();
		
		try {
			conn = KeyClass.getConnection (getInitParameter ("url"), getInitParameter ("id"), getInitParameter ("pw"));
			pstmt = conn.prepareStatement ("select * from exam where examNum = ?");
			pstmt.setInt (1, Integer.parseInt (request.getParameter ("num")));
			rset = pstmt.executeQuery ();
			
			if (rset.next ()) {
				Date examDate = rset.getDate ("examDate");
				int examTimeStart = rset.getInt ("examTimeStart");
				int examTimeClose = rset.getInt ("examTimeClose");
				
				if (!(toDay.toString().equals (examDate.toString ()))) {
					response.setContentType ("text/html; charset=utf-8");
					PrintWriter out = response.getWriter ();
					out.println("<script>");
					out.println("alert ('�������� �ƴմϴ�.');");
					out.println("history.back();");
					out.println("</script>");
				} else if (cal.get (Calendar.HOUR_OF_DAY) < examTimeStart) {
					response.setContentType ("text/html; charset=utf-8");
					PrintWriter out = response.getWriter ();
					out.println("<script>");
					out.println("alert ('���� �غ����Դϴ�.');");
					out.println("history.back();");
					out.println("</script>");
				} else if (cal.get (Calendar.HOUR_OF_DAY) >= examTimeClose) {
					response.setContentType ("text/html; charset=utf-8");
					PrintWriter out = response.getWriter ();
					out.println("<script>");
					out.println("alert ('������ ����Ǿ����ϴ�..');");
					out.println("history.back();");
					out.println("</script>");
				} else {
					request.getRequestDispatcher ("template/management/mContent_student/exam.jsp").forward (request, response);
				}
			} else {
				response.setContentType ("text/html; charset=utf-8");
				PrintWriter out = response.getWriter ();
				out.println("<script>");
				out.println("alert ('������ �������� �ʽ��ϴ�.');");
				out.println("history.back();");
				out.println("</script>");
			}
		} catch (Exception e) { e.printStackTrace ();
		} finally {
			try {
				if (rset != null) rset.close ();
				if (pstmt != null) pstmt.close ();
				if (conn != null) conn.close ();
			} catch (Exception e) {}
		}
	}
}