package com.hanbit.key;

import java.sql.Date;

public class AttendanceKey {
	private String userID;
	private int lecNum;
	private Date lecDate;
	private Date inTime;
	private Date outTime;
	private int attendanceState;
	
	public AttendanceKey () {}
	public AttendanceKey (String userID, int lecNum, Date lecDate, Date inTime, Date outTime, int attendanceState) {
		this.userID = userID;
		this.lecNum = lecNum;
		this.lecDate = lecDate;
		this.inTime = inTime;
		this.outTime = outTime;
		this.attendanceState = attendanceState;
	}
	
	public String getUserID () { return userID; }
	public int getLecNum () { return lecNum; }
	public Date getLecDate () { return lecDate; }
	public Date getInTime () { return inTime; }
	public Date getOutTime () { return outTime; }
	public int getAttendanceState () { return attendanceState; }
	
	public void setUserID (String userID) { this.userID = userID; }
	public void setLecNum (int lecNum) { this.lecNum = lecNum; }
	public void setLecDate (Date lecDate) { this.lecDate = lecDate; }
	public void setInTime (Date inTime) { this.inTime = inTime; }
	public void setOutTime (Date outTime) { this.outTime = outTime; }
	public void setAttendanceState (int attendanceState) { this.attendanceState = attendanceState; }
	public void addAttendanceState (int attendanceState) { this.attendanceState += attendanceState; }
}