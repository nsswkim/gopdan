package com.hanbit.util;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;

import com.hanbit.key.KeyClass;
import com.hanbit.key.UserKey;

public class Util {
	public String pageNaming (int count) {
		String stringNum = Integer.toString (count);
		if (stringNum.length() < 2) stringNum = "0" + stringNum;
		
		return stringNum;
	}
	
	public static int min (int a, int b) { return a<b? a : b; }
}