drop table exam;
create table exam (
	examNum int auto_increment primary key,
	lecNum int not null,
	examTitle varchar(40) not null,
	examInfo varchar(40),
	examDate DATE,
	examTimeStart int default 9,
	examTimeClose int default 18
);
select * from exam;
commit;