drop table examresult;
create table examresult (
	idx int primary key auto_increment,
	id varchar(128) not null,
	lecNum int not null,
	examNum int not null,
	selectionPlace varchar not null,
	correction varchar not null,
	selection varchar not null
);
select * from examresult;
commit;