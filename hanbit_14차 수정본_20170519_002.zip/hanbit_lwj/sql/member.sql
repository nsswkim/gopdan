drop table member;
CREATE TABLE member (
	num INT auto_increment NOT NULL,
	name VARCHAR(10) NOT NULL,
	id VARCHAR(10) NOT NULL,
	passwd VARCHAR(10) NOT NULL,
	email VARCHAR(30),
	nalja DATE,
	phone VARCHAR(20),
	job INT default 0,
	classNum INT default 0,
	PRIMARY KEY (num)
);
--dummy
insert into member values (num,'������01','student01','1234','student01@hb.com',sysdate(),'010-1234-5678', 4, 1001);
insert into member values (num,'������02','student02','2345','student02@hb.com',sysdate(),'010-9123-4567', 4, 0);
insert into member values (num,'������03','student03','3456','student03@hb.com',sysdate(),'010-8912-3456', 4, 0);
insert into member values (num,'������04','student04','4567','student04@hb.com',sysdate(),'010-7891-2345', 4, 0);
insert into member values (num,'������05','student05','5678','student05@hb.com',sysdate(),'010-6789-1324', 4, 0);
insert into member values (num,'������06','student06','6789','student06@hb.com',sysdate(),'010-5678-9123', 4, 0);
insert into member values (num,'������07','student07','7890','student07@hb.com',sysdate(),'010-4567-8912', 4, 0);
insert into member values (num,'������08','student08','8901','student08@hb.com',sysdate(),'010-3456-7891', 4, 0);
insert into member values (num,'������09','student09','9012','student09@hb.com',sysdate(),'010-2345-6789', 0, 0);
insert into member values (num,'������10','student10','0123','student10@hb.com',sysdate(),'010-1234-6789', 0, 0);
insert into member values (num,'����01','teacher01','1234','dang@hb.com',sysdate(),'010-4321-8765', 8, 0);
insert into member values (num,'����02','teacher02','2345','mather@hb.com',sysdate(),'010-8765-1423', 8, 0);
insert into member values (num,'������','company01','1111','company@hb.com',sysdate(),'010-1357-3579', 20, 0);
insert into member values (num,'������','teamSales','2222','sales@hb.com',sysdate(),'010-2468-8642', 80, 0);
insert into member values (num,'������','teamExect','3333','execute@hb.com',sysdate(),'010-0000-0000', 84, 0);
--dummy
select * from member;
commit;