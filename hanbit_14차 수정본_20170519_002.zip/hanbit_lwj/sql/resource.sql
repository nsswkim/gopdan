drop table resource;
create table resource(
	num	int primary key auto_increment,
	lecNum int not null,
	uploader varchar(128),
	postPw varchar(128),
	uploadTitle varchar(128),
	uploadContent varchar(128),
	uploadDate date,
	datapath varchar(128),
	authRead int default 0
);
select * from resource;
commit;