package com.hanbit.control;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanbit.key.KeyClass;

@WebServlet(
		urlPatterns = { "/addExamQuestion" }, 
		initParams = { 
				@WebInitParam(name = "url", value = "jdbc:mysql://localhost:3306/testdb"), 
				@WebInitParam(name = "id", value = "scott"), 
				@WebInitParam(name = "pw", value = "tiger")
		})
public class AddExamQuestion extends HttpServlet {
	protected void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding ("UTF-8");
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		int examNum = Integer.parseInt (request.getParameter ("examNum"));
		int exqPoint = Integer.parseInt (request.getParameter ("exqPoint"));
		String exqText = request.getParameter ("exqText");
		String selectO = request.getParameter ("selectO");
		String selectX1 = request.getParameter ("selectX1");
		String selectX2 = request.getParameter ("selectX2");
		String selectX3 = request.getParameter ("selectX3");
		String selectX4 = request.getParameter ("selectX4");
		
		try {
			conn = KeyClass.getConnection (getInitParameter ("url"), getInitParameter ("id"), getInitParameter ("pw"));
			pstmt = conn.prepareStatement ("insert into examquestions values (idx, ?, ?, ?, ?, ?, ?, ?, ?)");
			pstmt.setInt (1, examNum);
			pstmt.setInt (2, exqPoint);
			pstmt.setString (3, exqText);
			pstmt.setString (4, selectO);
			pstmt.setString (5, selectX1);
			pstmt.setString (6, selectX2);
			pstmt.setString (7, selectX3);
			pstmt.setString (8, selectX4);
			pstmt.executeUpdate ();
		} catch (Exception e) { e.printStackTrace ();
		} finally {
			try {
				if (rset != null) rset.close ();
				if (pstmt != null) pstmt.close ();
				if (conn != null) conn.close ();
			} catch (Exception e) {}
		}
		
		response.sendRedirect ("redirectExamQuestion?num=" + examNum);
	}
}