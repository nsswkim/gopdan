package com.hanbit.control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanbit.key.AttendanceKey;
import com.hanbit.key.KeyClass;
import com.hanbit.key.UserKey;

@SuppressWarnings("serial")
@WebServlet(
		urlPatterns = { "/submitAttendance" }, 
		initParams = { 
				@WebInitParam(name = "url", value = "jdbc:mysql://localhost:3306/testdb"), 
				@WebInitParam(name = "id", value = "scott"), 
				@WebInitParam(name = "pw", value = "tiger")
		})
public class AttendanceProc extends HttpServlet {
	protected void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding ("UTF-8");
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		Date checkTime = new java.sql.Date (Calendar.getInstance().getTime().getTime());
		Calendar cal = Calendar.getInstance ();
		boolean exist = false;
		boolean isRecorded = false;
		response.setContentType ("text/html; charset=utf-8");
		PrintWriter out = response.getWriter ();
		UserKey uk = (UserKey) request.getSession().getAttribute ("userkey");
		AttendanceKey ak = new AttendanceKey ();
		
		if (cal.get (Calendar.DAY_OF_MONTH) == Calendar.SUNDAY || cal.get (Calendar.DAY_OF_MONTH)== Calendar.SATURDAY) {
			out.println ("<script type='text/javascript'>");
			out.println ("alert ('�⼮���� �ƴմϴ�.');");
			out.println ("history.back ();");
			out.println ("</script>");
		} else if (cal.get (Calendar.HOUR_OF_DAY) <= 6 || cal.get (Calendar.HOUR_OF_DAY) >= 22) {
			out.println ("<script type='text/javascript'>");
			out.println ("alert ('�⼮�ð��� �ƴմϴ�.');");
			out.println ("history.back ();");
			out.println ("</script>");
		}
		
		try {
			conn = KeyClass.getConnection (getInitParameter ("url"), getInitParameter ("id"), getInitParameter ("pw"));
			
			try {
				pstmt = conn.prepareStatement ("select * from attendance where userID = ? and"
						+ " (inTime like '" + checkTime.toString () + "%' or outTime like '" + checkTime.toString () + "%')");
				pstmt.setString (1, uk.getId ());
				rset = pstmt.executeQuery ();
				
				ak = new AttendanceKey ();
				if (rset.next ()) {
					exist = true;
					ak.setUserID (rset.getString ("userID"));
					ak.setLecNum (rset.getInt ("lecNum"));
					ak.setLecDate (rset.getDate ("lecDate"));
					ak.setInTime (rset.getDate ("inTime"));
					ak.setOutTime (rset.getDate ("outTime"));
					if (ak.getOutTime () == null) isRecorded = true;
					ak.setAttendanceState (rset.getInt ("attendanceState"));
				} else {
					exist = false;
					ak.setUserID (uk.getId ());
					ak.setLecNum (uk.getClassNum ());
					ak.setLecDate (null);
					ak.setInTime (null);
					ak.setOutTime (null);
					ak.setAttendanceState (0);
				}
			} catch (Exception e) { e.printStackTrace ();
			} finally {
				try {
					if (rset != null) rset.close ();
					if (pstmt != null) pstmt.close ();
				} catch (Exception e) {}
			}
			
			/* 13�� ���� �⼮Ȯ�� */
			if (cal.get (Calendar.HOUR_OF_DAY) < 13) {
				/* ���� �⼮ */ 
				if (cal.get (Calendar.HOUR_OF_DAY) < 9 || (cal.get (Calendar.HOUR_OF_DAY) == 9 && cal.get (Calendar.MINUTE) < 10)) ak.setAttendanceState (6);
				/* ���� �⼮ */
				else ak.setAttendanceState (3);
				ak.setInTime (new Date (cal.getTime().getTime()));
			} else { /* 13�� ���� ���Ȯ�� */
				/* ���� ��� */
				if (cal.get (Calendar.HOUR_OF_DAY) < 17 || (cal.get (Calendar.HOUR_OF_DAY) == 17 && cal.get (Calendar.HOUR_OF_DAY) < 50)
						&& ak.getAttendanceState() % 3 == 0) ak.addAttendanceState (1);
				/* ���� ��� */
				else if (ak.getAttendanceState() % 3 == 0) ak.setAttendanceState (2);
				
				if (ak.getOutTime() == null) ak.setOutTime (new Date (cal.getTime().getTime()));
				else ak.setOutTime (ak.getOutTime ());
			}
			
			try {
				if (exist && isRecorded) {
					pstmt = conn.prepareStatement ("update attendance set inTime = ?, outTime = ?, attendanceState = ? where userID = ?"
							+ " and (inTime like '" + checkTime.toString () + "%' or outTime like '" + checkTime.toString () + "%')");
					pstmt.setDate (1, ak.getInTime ());
					pstmt.setDate (2, ak.getOutTime ());
					pstmt.setInt (3, ak.getAttendanceState ());
					pstmt.setString (4, ak.getUserID ());
					pstmt.executeUpdate ();
				} else if (!exist) {
					pstmt = conn.prepareStatement ("insert into attendance values (?, ?, ?, ?, ?, ?)");
					pstmt.setString (1, ak.getUserID ());
					pstmt.setInt (2, ak.getLecNum ());
					pstmt.setDate (3, checkTime);
					pstmt.setDate (4, ak.getInTime ());
					pstmt.setDate (5, ak.getOutTime ());
					pstmt.setInt (6, ak.getAttendanceState ());
					pstmt.executeUpdate ();
				} else {}
			} catch (Exception e) { e.printStackTrace ();
			} finally {
				try {
					if (rset != null) rset.close ();
					if (pstmt != null) pstmt.close ();
				} catch (Exception e) {}
			}
		} catch (Exception e) { e.printStackTrace ();
		} finally {
			try {
				if (conn != null) conn.close ();
			} catch (Exception e) {}
		}
		
		response.sendRedirect ("management.jsp");
	}
}