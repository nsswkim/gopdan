package com.hanbit.key;

import java.sql.Date;

public class ResourceKey {
	private int num;
	private int lecNum;
	private String uploader;
	private String postPw;
	private String uploadTitle;
	private String uploadContent;
	private Date uploadDate;
	private String datapath;
	private int authRead;
	
	public ResourceKey () {}

	public int getNum () { return num; }
	public int getLecNum () { return lecNum; }
	public String getUploader () { return uploader; }
	public String getPostPw () { return postPw; }
	public String getUploadTitle () { return uploadTitle; }
	public String getUploadContent () { return uploadContent; }
	public Date getUploadDate () { return uploadDate; }
	public String getDatapath () { return datapath; }
	public int getAuthRead () { return authRead; }

	public void setNum (int num) { this.num = num; }
	public void setLecNum (int lecNum) { this.lecNum = lecNum; }
	public void setUploader (String uploader) { this.uploader = uploader; }
	public void setPostPw (String postPw) { this.postPw = postPw; }
	public void setUploadTitle (String uploadTitle) { this.uploadTitle = uploadTitle; }
	public void setUploadContent (String uploadContent) { this.uploadContent = uploadContent; }
	public void setUploadDate (Date uploadDate) { this.uploadDate = uploadDate; }
	public void setDatapath (String datapath) { this.datapath = datapath; }
	public void setAuthRead (int authRead) { this.authRead = authRead; }
}