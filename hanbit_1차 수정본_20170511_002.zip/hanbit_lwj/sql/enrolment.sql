drop table enrolment;
create table enrolment (
	lecNum int auto_increment primary key,
	lecLocation varchar(40) not null,
	lecCapacity int default 10,
	lecPicture varchar(256)
);
select * from enrolment;
commit;