package com.hanbit.control;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanbit.key.KeyClass;
import com.hanbit.key.UserKey;

@SuppressWarnings("serial")
@WebServlet(
		urlPatterns = { "/write" }, 
		initParams = { 
				@WebInitParam(name = "url", value = "jdbc:mysql://localhost:3306/testdb"), 
				@WebInitParam(name = "id", value = "scott"), 
				@WebInitParam(name = "pw", value = "tiger"),
				@WebInitParam(name = "adminid", value = "admin"), 
				@WebInitParam(name = "adminpw", value = "administrator")
		})
public class EditWrite extends HttpServlet {
	protected void doGet (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding ("UTF-8");
		
		int num = Integer.parseInt (request.getParameter ("num"));
		int write = Integer.parseInt (request.getParameter ("write"));
		int originWrite = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		if (((UserKey) request.getSession().getAttribute("userkey")).getId().equals (getInitParameter ("adminid")) &&
			((UserKey) request.getSession().getAttribute("userkey")).getPw().equals (getInitParameter ("adminpw"))) {
			try {
				conn = KeyClass.getConnection (getInitParameter ("url"), getInitParameter ("id"), getInitParameter ("pw"));
				pstmt = conn.prepareStatement ("select * from member where num=?");
				pstmt.setInt (1, num);
				rset = pstmt.executeQuery ();
				
				rset.next ();
				originWrite = rset.getInt ("job");
			} catch (Exception e) { e.printStackTrace ();
			} finally {
				try {
					if (pstmt != null) pstmt.close ();
					if (conn != null) conn.close ();
				} catch (Exception e) {}
			}
			
			write = originWrite - (originWrite % 4) + write;
			
			try {
				conn = KeyClass.getConnection (getInitParameter ("url"), getInitParameter ("id"), getInitParameter ("pw"));
				pstmt = conn.prepareStatement ("update member set job=? where num=?");
				pstmt.setInt (1, write);
				pstmt.setInt (2, num);
				pstmt.executeUpdate ();
			} catch (Exception e) { e.printStackTrace ();
			} finally {
				try {
					if (pstmt != null) pstmt.close ();
					if (conn != null) conn.close ();
				} catch (Exception e) {}
			}
		} else {
			response.sendRedirect ("main.jsp");			
		}
		
		response.sendRedirect ("management.jsp");
	}
}