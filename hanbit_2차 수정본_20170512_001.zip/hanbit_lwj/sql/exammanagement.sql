drop table exammanagement;
create table exammanagement (
	examNum int auto_increment primary key,
	examTimeStart int not null,
	examTimeClose int not null
);
select * from exammanagement;
commit;