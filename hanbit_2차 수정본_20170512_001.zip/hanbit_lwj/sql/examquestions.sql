drop table examquestions;
create table examquestions (
	exqNum int not null,
	exqType int default 0,
	exqText varchar(1024) not null,
	exqCrct varchar(1024) not null,
	exqicr1 varchar(1024) not null,
	exqicr2 varchar(1024) not null,
	exqicr3 varchar(1024) not null,
	exqicr4 varchar(1024) not null
);
select * from examquestions;
commit;