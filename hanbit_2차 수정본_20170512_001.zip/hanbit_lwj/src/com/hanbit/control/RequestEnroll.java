package com.hanbit.control;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanbit.key.KeyClass;
import com.hanbit.key.UserKey;

@WebServlet(
		urlPatterns = { "/requestEnroll" }, 
		initParams = { 
				@WebInitParam(name = "url", value = "jdbc:mysql://localhost:3306/testdb"), 
				@WebInitParam(name = "id", value = "scott"), 
				@WebInitParam(name = "pw", value = "tiger")
		})
public class RequestEnroll extends HttpServlet {
	protected void doGet (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding ("UTF-8");
		
		int lecNum = Integer.parseInt (request.getParameter ("num"));
		String query = "";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		UserKey uk = new UserKey ();
		
		if (lecNum < 0) query = "update member set classNum = 0 where num=?";
		else query = "update member set classNum=" + lecNum + " where num=?";
		
		try {
			conn = KeyClass.getConnection (getInitParameter ("url"), getInitParameter ("id"), getInitParameter ("pw"));
			try {
				pstmt = conn.prepareStatement (query);
				pstmt.setInt (1, ((UserKey) request.getSession().getAttribute("userkey")).getNum ());
				pstmt.executeUpdate ();
			} catch (Exception e) {
			} finally {
				try {
					if (rset != null) rset.close ();
					if (pstmt != null) pstmt.close ();
				} catch (Exception e) {}
			}
			
			try {
				pstmt = conn.prepareStatement ("select * from member where num=?");
				pstmt.setInt (1, ((UserKey) request.getSession().getAttribute("userkey")).getNum ());
				rset = pstmt.executeQuery ();
				
				if (rset.next ()) {
					uk.setNum (rset.getInt ("num"));
					uk.setName (rset.getString ("name"));
					uk.setId (rset.getString ("id"));
					uk.setPw (rset.getString ("passwd"));
					uk.setEmail (rset.getString ("email"));
					uk.setDate (null);
					uk.setPhone (rset.getString ("phone"));
					uk.setJob (rset.getInt ("job"));
					uk.setClassNum (rset.getInt ("classNum"));
				}
			} catch (Exception e) {
			} finally {
				try {
					if (rset != null) rset.close ();
					if (pstmt != null) pstmt.close ();
				} catch (Exception e) {}
			}
		} catch (Exception e) {
		} finally {
			try {
				if (rset != null) rset.close ();
				if (pstmt != null) pstmt.close ();
				if (conn != null) conn.close ();
			} catch (Exception e) {}
		}
		
		request.getSession().removeAttribute ("userkey");
		request.getSession().setAttribute ("userkey", uk);
		
		response.sendRedirect ("management.jsp");
	}
}