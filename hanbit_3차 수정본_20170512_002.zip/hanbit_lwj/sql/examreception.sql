drop table examreception;
create table examreception(
	lecNum int not null,
	examNum int auto_increment primary key,
	examTitle varchar(40) not null,
	examInfo varchar(40),
	examDate DATE not null
);
select * from examreception;
commit;