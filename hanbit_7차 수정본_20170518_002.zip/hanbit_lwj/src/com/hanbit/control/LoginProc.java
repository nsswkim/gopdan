package com.hanbit.control;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanbit.key.KeyClass;
import com.hanbit.key.UserKey;

@WebServlet(
		urlPatterns = { "/loginquery" }, 
		initParams = { 
				@WebInitParam(name = "url", value = "jdbc:mysql://localhost:3306/testdb"), 
				@WebInitParam(name = "id", value = "scott"), 
				@WebInitParam(name = "pw", value = "tiger"),
				@WebInitParam(name = "adminid", value = "admin"), 
				@WebInitParam(name = "adminpw", value = "administrator")
		})
public class LoginProc extends HttpServlet {
	private static final long serialVersionUID = 1L;
	UserKey uk;
	
	protected void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding ("UTF-8");
		String userid = request.getParameter ("id").trim ();
		String userpw = request.getParameter ("pw").trim ();
		
		boolean result = false;
		uk = null;
		
		if (!userid.isEmpty () && !userpw.isEmpty ()) {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rset = null;
			
			try {
				conn = KeyClass.getConnection (getInitParameter ("url"), getInitParameter ("id"), getInitParameter ("pw"));
				pstmt = conn.prepareStatement ("select * from member where id=? and passwd=?");
				pstmt.setString (1, userid);
				pstmt.setString (2, userpw);
				rset = pstmt.executeQuery ();
				
				if (rset.next ()) {
					result = true;
					
					uk = new UserKey ();
					uk.setNum (rset.getInt ("num"));
					uk.setName (rset.getString ("name"));
					uk.setId (rset.getString ("id"));
					uk.setPw (rset.getString ("passwd"));
					uk.setEmail (rset.getString ("email"));
					uk.setDate (null);
					uk.setPhone (rset.getString ("phone"));
					uk.setJob (rset.getInt ("job"));
					uk.setClassNum (rset.getInt ("classNum"));
				} else if (userid.equals (getInitParameter ("adminid")) && userpw.equals (getInitParameter ("adminpw"))) {
					result = true;
					
					uk = new UserKey ();
					uk.setNum (0);
					uk.setName (getInitParameter ("adminid"));
					uk.setId (getInitParameter ("adminid"));
					uk.setPw ("administrator");
					uk.setEmail ("admin@hanbit.com");
					uk.setPhone ("010-1234-5678");
					uk.setJob (100);
					uk.setClassNum (0);
				}
			} catch (Exception e) { e.printStackTrace ();
			} finally {
				try {
					if (rset != null) rset.close ();
					if (pstmt != null) pstmt.close ();
					if (conn != null) conn.close ();
				} catch (Exception e) {}
			}
			
			if (result) {
				request.setAttribute ("login", true);
				request.getSession().setAttribute ("userkey", uk);
				response.sendRedirect ("main.jsp");
			} else { 
				request.setAttribute ("login", false);
				response.sendRedirect ("main.jsp");
			}
		} else {
			request.setAttribute ("login", false);
			response.sendRedirect ("main.jsp");
		}
	}
}