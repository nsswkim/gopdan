drop table enrolment;
create table enrolment (
	lecNum int auto_increment primary key,
	lecLocation varchar(40) not null,
	lecCapacity int default 10,
	lecPicture varchar(256),
	enrollState int default 0
);
--dummy
insert into enrolment values (1001, "�Ѻ��������� ȫ����", 20, "en.jpg", 1);
--dummy
select * from enrolment;
commit;