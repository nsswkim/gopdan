package com.hanbit.control;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
@WebServlet(
		urlPatterns = { "/editExam" }, 
		initParams = { 
				@WebInitParam(name = "url", value = "jdbc:mysql://localhost:3306/testdb"), 
				@WebInitParam(name = "id", value = "scott"), 
				@WebInitParam(name = "pw", value = "tiger")
		})
public class EditExam extends HttpServlet {
	protected void doPost (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding ("UTF-8");
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		int examNum = Integer.parseInt (request.getParameter ("examNum"));
		int lecNum = Integer.parseInt (request.getParameter ("lecNum"));
		String examTitle = request.getParameter ("examTitle");
		String examInfo = request.getParameter ("examInfo");
		String examDate = request.getParameter ("examDate");
		int examTimeStart = Integer.parseInt (request.getParameter ("examTimeStart"));
		int examTimeClose = Integer.parseInt (request.getParameter ("examTimeClose"));
		
		System.out.println (examNum);
		System.out.println (lecNum);
		System.out.println (examTitle);
		System.out.println (examInfo);
		System.out.println (examDate);
		System.out.println (examTimeStart);
		System.out.println (examTimeClose);
		
		response.sendRedirect ("redirectExamQuestion?num=" + examNum);
	}
}