package com.hanbit.control;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanbit.key.KeyClass;
import com.hanbit.key.UserKey;
@SuppressWarnings("serial")
@WebServlet(
		urlPatterns = { "/reviewLecture" }, 
		initParams = { 
				@WebInitParam(name = "url", value = "jdbc:mysql://localhost:3306/testdb"), 
				@WebInitParam(name = "id", value = "scott"), 
				@WebInitParam(name = "pw", value = "tiger")
		})
public class ReviewLecture extends HttpServlet {
	protected void doGet (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding ("UTF-8");
		
		int lecNum = 0;
		int flag = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		if (((UserKey) request.getSession().getAttribute("userkey")).getJob() >= 84) {
			lecNum = Integer.parseInt (request.getParameter ("num"));
			flag = Integer.parseInt (request.getParameter ("flag"));
			
			try {
				conn = KeyClass.getConnection (getInitParameter ("url"), getInitParameter ("id"), getInitParameter ("pw"));
				
				try {
					pstmt = conn.prepareStatement ("update lecture set lecState=? where lecNum=?");
					switch (flag) {
						case 1 : pstmt.setInt (1, 2); break;
						case 2 : pstmt.setInt (1, 1); break;
						case 3 : pstmt.setInt (1, -1); break;
					}
					pstmt.setInt (2, lecNum);
					pstmt.executeUpdate ();
				} catch (Exception e) { e.printStackTrace ();
				} finally {
					try {
						if (pstmt != null) pstmt.close ();
					} catch (Exception e) {}
				}
				
				if (flag == 1) try {
					pstmt = conn.prepareStatement ("update member set classNum = ? where id = any (select profId from lecture where lecNum = ?)");
					pstmt.setInt (1, lecNum);
					pstmt.setInt (2, lecNum);
					pstmt.executeUpdate ();
				} catch (Exception e) { e.printStackTrace ();
				} finally {
					try {
						if (pstmt != null) pstmt.close ();
					} catch (Exception e) {}
				}
			} catch (Exception e) { e.printStackTrace ();
			} finally {
				try {
					if (pstmt != null) pstmt.close ();
					if (conn != null) conn.close ();
				} catch (Exception e) {}
			}
		} else response.sendRedirect ("main.jsp");
		
		response.sendRedirect ("management.jsp");
	}
}