package com.hanbit.key;

public class ExamQuestionKey {
	private int examNum;
	private int exqPoint;
	private String exqText;
	private String selectO;
	private String selectX1;
	private String selectX2;
	private String selectX3;
	private String selectX4;
	
	public ExamQuestionKey () {}
	
	public int getExamNum () { return examNum; }
	public int getExqPoint () { return exqPoint; }
	public String getExqText () { return exqText; } 
	public String getSelectO () { return selectO; }
	public String getSelectX1 () { return selectX1; }
	public String getSelectX2 () { return selectX2; }
	public String getSelectX3 () { return selectX3; }
	public String getSelectX4 () { return selectX4; }
	
	public void setExamNum (int examNum) { this.examNum = examNum; }
	public void setExqPoint (int exqPoint) { this.exqPoint = exqPoint; }
	public void setExqText (String exqText) { this.exqText = exqText; }
	public void setSelectO (String selectO) { this.selectO = selectO; }
	public void setSelectX1 (String selectX1) { this.selectX1 = selectX1; }
	public void setSelectX2 (String selectX2) { this.selectX2 = selectX2; }
	public void setSelectX3 (String selectX3) { this.selectX3 = selectX3; }
	public void setSelectX4 (String selectX4) { this.selectX4 = selectX4; }
}