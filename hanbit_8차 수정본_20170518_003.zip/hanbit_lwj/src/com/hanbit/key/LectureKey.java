package com.hanbit.key;

import java.sql.Date;

public class LectureKey {
	private String profId;
	private int lecNum;
	private String lecName;
	private int lecState;
	private Date lecDateStart;
	private Date lecDateClose;
	private int lecTimeStart;
	private int lecTimeClose;
	private String lecTimeDesc;
	private String lecInfo;
	private String lecDesc;
	private int lecListener;
	private String lecExamInfo;
	
	public String getProfId () { return profId; }
	public int getLecNum () { return lecNum; }
	public String getLecName () { return lecName; }
	public int getLecState () { return lecState; }
	public Date getLecDateStart () { return lecDateStart; }
	public Date getLecDateClose () { return lecDateClose; }
	public int getLecTimeStart () { return lecTimeStart; }
	public int getLecTimeClose () { return lecTimeClose; }
	public String getLecTimeDesc () { return lecTimeDesc; }
	public String getLecInfo () { return lecInfo; }
	public String getLecDesc () { return lecDesc; }
	public int getLecListener () { return lecListener; }
	public String getLecExamInfo () { return lecExamInfo; }
	
	public void setProfId (String profId) { this.profId = profId; }
	public void setLecNum (int lecNum) { this.lecNum = lecNum; }
	public void setLecName (String lecName) { this.lecName = lecName; }
	public void setLecState (int lecState) { this.lecState = lecState; }
	public void setLecDateStart (Date lecDateStart) { this.lecDateStart = lecDateStart; }
	public void setLecDateClose (Date lecDateClose) { this.lecDateClose = lecDateClose; }
	public void setLecTimeStart (int lecTimeStart) { this.lecTimeStart = lecTimeStart; }
	public void setLecTimeClose (int lecTimeClose) { this.lecTimeClose = lecTimeClose; }
	public void setLecTimeDesc (String lecTimeDesc) { this.lecTimeDesc = lecTimeDesc; }
	public void setLecInfo (String lecInfo) { this.lecInfo = lecInfo; }
	public void setLecDesc (String lecDesc) { this.lecDesc = lecDesc; }
	public void setLecListener (int lecListener) { this.lecListener = lecListener; }
	public void setLecExamInfo (String lecExamInfo) { this.lecExamInfo = lecExamInfo; }
}